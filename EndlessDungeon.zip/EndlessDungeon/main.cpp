//
//  main.cpp
//  
//
//  Created by Arthur Bacon on 11/27/16.
//
//

#include <stdio.h>
#include <iostream>
#include <list>
#include <vector>
#include "Character.h"
#include "Player.h"
#include "Dragon.h"
#include "Game.h"

using namespace endless_game;


int main() {
  Game mainGame;
  mainGame.playGame();
  
  return 0;
}
